from insurance.dao import entities
from insurance.dao.dao import DAO
from insurance.utils.errors import NotFoundError, UnprocessableError, InernalServerError


class Policy:
    '''
    Service class to get/create/update policies
    '''

    def __init__(self):
        self.__dao_obj = DAO()
        self.min_premium = 0
        self.max_premium = 1000000

    def validate_premium(self, premium):
        if premium >= self.min_premium and premium <= self.max_premium:
            return True
        else:
            return False

    def get(self, policy_id=None, customer_id=None):
        '''
        Function to get the policies
        '''
        output = dict()
        try:
            if policy_id and customer_id:
                policy_objs = self.__dao_obj.get_where(
                    entities.Plicies, f"id = {policy_id} and customer_id = {customer_id}")
                output['data'] = policy_objs
            elif policy_id:
                policy_obj = self.__dao_obj.get_item(
                    entities.Plicies, policy_id)
                output['data'] = policy_obj
            else:
                policy_objs = self.__dao_obj.get_all(entities.Plicies)
                output['data'] = policy_objs
            return output
        except Exception as e:
            print(str(e))
            raise

    def create(self,
               customer_id,
               fuel,
               vehicle_segment,
               premium,
               bodily_injury_liability,
               personal_injury_protection,
               property_damage_liability,
               collision,
               comprehensive,
               customer_gender,
               customer_income_group,
               customer_region,
               customer_marital_status):
        '''
        Function to create the policies
        '''
        output = dict()
        try:
            if not self.validate_premium(premium):
                raise UnprocessableError(
                    f"Premium should be between {self.min_premium} and {self.max_premium}.")
            policy_obj = entities.Policy(customer_id,
                                         fuel,
                                         vehicle_segment,
                                         premium,
                                         bodily_injury_liability,
                                         personal_injury_protection,
                                         property_damage_liability,
                                         collision,
                                         comprehensive,
                                         customer_gender,
                                         customer_income_group,
                                         customer_region,
                                         customer_marital_status)
            policy_obj, session = self.__dao_obj.put(
                entities.Policy, policy_obj)
            session.commit()
            output['data'] = policy_obj
            output['message'] = f"Policy with ID {policy_id} created successfully."
            return output
        except Exception as e:
            if session:
                session.rollback()
            print(str(e))
            raise
        finally:
            if session:
                session.close()

    def update(self,
               policy_id,
               fuel,
               vehicle_segment,
               premium,
               bodily_injury_liability,
               personal_injury_protection,
               property_damage_liability,
               collision,
               comprehensive,
               customer_gender,
               customer_income_group,
               customer_region,
               customer_marital_status):
        '''
        Function to update the policies
        '''
        output = dict()
        session = None
        try:
            policy_obj, session = self.__dao_obj.get_item(
                entities.Plicies, policy_id, return_session=True)
            if policy_obj is None:
                raise NotFoundError(
                    f"Policy with ID {policy_id} does not exist.")
            if not self.validate_premium(premium):
                raise UnprocessableError(
                    f"Premium should be between {self.min_premium} and {self.max_premium}.")
            policy_obj.fuel = fuel
            policy_obj.vehicle_segment = vehicle_segment
            policy_obj.premium = premium
            policy_obj.bodily_injury_liability = bodily_injury_liability
            policy_obj.personal_injury_protection = personal_injury_protection
            policy_obj.property_damage_liability = property_damage_liability
            policy_obj.collision = collision
            policy_obj.comprehensive = comprehensive
            policy_obj.customer_gender = customer_gender
            policy_obj.customer_income_group = customer_income_group
            policy_obj.customer_region = customer_region
            policy_obj.customer_marital_status = customer_marital_status
            session.commit()
            output['data'] = policy_obj
            output['message'] = f"Policy with ID {policy_id} updated successfully."
            return output
        except NotFoundError as e:
            print(str(e))
            raise
        except Exception as e:
            if session:
                session.rollback()
            print(str(e))
            raise
        finally:
            if session:
                session.close()

    def delete(self, policy_id):
        '''
        Function to delete the policies
        '''
        output = dict()
        session = None
        try:
            policy_obj, session = self.__dao_obj.get_item(
                entities.Plicies, policy_id, return_session=True)
            if policy_obj is None:
                raise NotFoundError(
                    f"Policy with ID {policy_id} does not exist.")
            session.delete(policy_obj)
            session.commit()
            output['message'] = f"Policy with ID {policy_id} deleted successfully."
            return output
        except NotFoundError as e:
            print(str(e))
            raise
        except Exception as e:
            if session:
                session.rollback()
            print(str(e))
            raise
        finally:
            if session:
                session.close()
