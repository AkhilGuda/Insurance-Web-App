class NotFoundError(Exception):
    pass

class UnprocessableError(Exception):
    pass

class InernalServerError(Exception):
    pass